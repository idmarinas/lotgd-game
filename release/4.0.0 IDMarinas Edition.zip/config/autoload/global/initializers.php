<?php

return [
    'service_manager' => [
        'initializers' => []
    ]
];
