<?php

return [
    'service_manager' => [
        'lazy_services' => []
    ]
];
