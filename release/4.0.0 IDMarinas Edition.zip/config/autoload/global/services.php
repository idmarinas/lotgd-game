<?php

return [
    'service_manager' => [
        'services' => []
    ]
];
