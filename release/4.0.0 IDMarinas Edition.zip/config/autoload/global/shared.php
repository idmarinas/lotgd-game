<?php

return [
    'service_manager' => [
        'shared' => []
    ]
];
