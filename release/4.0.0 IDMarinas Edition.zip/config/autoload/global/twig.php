<?php

return [
    'twig_extensions' => [//-- Custom extensions for Twig
        // Class\Name::class
    ]
];
