<?php

return [
    'lotgd_core' => [
        'doctrine' => [
            //-- Enable one of the cache drivers available on your server for Doctrine

            // 'cache_class' => Doctrine\Common\Cache\ApcCache::class,
            // 'cache_class' => Doctrine\Common\Cache\ApcuCache::class,
            // 'cache_class' => Doctrine\Common\Cache\MemcacheCache::class,
            // 'cache_class' => Doctrine\Common\Cache\MemcachedCache::class,
            // 'cache_class' => Doctrine\Common\Cache\XcacheCache::class,
            // 'cache_class' => Doctrine\Common\Cache\RedisCache::class
        ]
    ]
];
