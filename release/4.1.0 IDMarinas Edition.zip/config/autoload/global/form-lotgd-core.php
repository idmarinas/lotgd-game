<?php

/**
 * Create forms via Service Manager and Form Factory
 */

return [
    'forms' => [
        'Lotgd\Core\Form\Configuration' => include 'data/form/core/grotto/configuration/input.php'
    ]
];
