<?php

return [
    'input_filter_specs' => [
        'Lotgd\Core\Form\Filter\Configuration' => include 'data/form/core/grotto/configuration/filter.php'
    ]
];
