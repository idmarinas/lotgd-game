<?php

return [
    'service_manager' => [
        'invokables' => []
    ]
];
