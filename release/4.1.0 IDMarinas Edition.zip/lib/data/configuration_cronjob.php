<?php

return [
    'newdaycron' => 'Let the newday-runonce run via a cronjob,bool'
];
