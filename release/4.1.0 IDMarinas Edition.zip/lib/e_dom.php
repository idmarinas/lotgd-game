<?php

// translator ready
// mail ready
// addnews ready
// mail ready
rawoutput("<script language='JavaScript' src='resources/e_dom.js'></script>");
