<?php

// translator ready
// mail ready
// addnews ready
// mail ready
\LotgdResponse::pageAddContent("<script language='JavaScript' src='resources/e_dom.js'></script>");
