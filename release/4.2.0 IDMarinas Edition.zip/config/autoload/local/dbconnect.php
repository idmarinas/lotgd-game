<?php
/**
 * This file is automatically created by installer.php
 *
 * @create Jan 30, 2020 06:15 pm
 */


return [
    'lotgd_core' => [
        'db' => [
            'adapter' => [
                'driver' => 'Pdo_Mysql',
                'hostname' => '127.0.0.1',
                // 'database' => 'lotgd_dev',
                'database' => 'lotgd_test',
                'charset' => 'utf8',
                'collate' => 'utf8_unicode_ci',
                'username' => 'root',
                'password' => '',
            ],
            'prefix' => '',
        ],
    ],
    'doctrine' => [
        'connection' => [
            'orm_default' => [
                'params' => [
                    'driver' => 'pdo_mysql', //-- By default is always mysql
                    'user' => 'root',
                    'password' => '',
                    // 'dbname' => 'lotgd_dev',
                    'dbname' => 'lotgd_test',
                    'charset' => 'utf8',
                    'collate' => 'utf8_unicode_ci'
                ]
            ]
        ]
    ]
];
