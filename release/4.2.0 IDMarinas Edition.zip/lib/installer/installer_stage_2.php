<?php

rawoutput(LotgdTheme::renderLotgdTemplate('core/page/installer/stage-2.twig', []));
