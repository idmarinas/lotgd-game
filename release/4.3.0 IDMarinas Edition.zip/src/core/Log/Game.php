<?php

/**
 * This file is part of Legend of the Green Dragon.
 *
 * @see https://github.com/idmarinas/lotgd-game
 *
 * @license https://github.com/idmarinas/lotgd-game/blob/master/LICENSE.txt
 * @author IDMarinas
 *
 * @since 4.0.0
 */

namespace Lotgd\Core\Log;

use Laminas\Db\Adapter\Adapter;
use Laminas\Log\Logger;
use Laminas\Log\Writer\Db as LogWriter;

class Game extends Logger
{
    //####
    //## Tablas de registro
    //######################
    const DEFAULT_LOG = 'gamelog';  //-- Es una entidad, Se creará una clase abstracta para poder crear varios logs diferentes

    /**
     * Map of table event.
     *
     * @var array
     */
    protected $mapping = [
        'timestamp' => 'date',
        'message'   => 'message',
        'extra'     => [
            'category' => 'category',
            'who'      => 'who',
            'field'    => 'field',
        ],
    ];

    /**
     * Table.
     *
     * @var string
     */
    protected $table = self::DEFAULT_LOG;

    /**
     * @var Adapter
     */
    protected $adapter;

    /**
     * {@inheritdoc}
     */
    public function log($priority, $message, $data = [])
    {
        $writer = new LogWriter($this->getAdapter(), $this->getTable(), $this->mapping);
        $this->addWriter($writer);

        $datos = [
            'timestamp' => time(),
            'userAgent' => ( ! $this->isAdmin() ? $this->getUserAgent() : self::USER_AGENT),
            'ipAddress' => ( ! $this->isAdmin() ? $this->getIpAddress() : self::IP_ADDRESS),
        ];
        $data = array_merge($datos, $data);

        return parent::log($priority, $message, $data);
    }

    /**
     * Configurar la tabla que se va ultilizar para guardar los datos.
     *
     * @var string
     *
     * @param mixed $table
     *
     * @return Application\Log\Game
     */
    public function setTable($table = self::DEFAULT_LOG)
    {
        $this->table = $table;

        return $this;
    }

    /**
     * Obtener la tabla que se va a utilizar para guardar los datos.
     *
     * @return string
     */
    public function getTable()
    {
        return $this->table;
    }

    /**
     * Configurar el Adapter que se va a utilizar.
     *
     * @var Adapter
     *
     * @return $this
     */
    public function setAdapter(Adapter $adapter)
    {
        $this->adapter = $adapter;

        return $this;
    }

    /**
     * Obtener el Adapter.
     *
     * @return Adapter
     */
    public function getAdapter()
    {
        return $this->adapter;
    }
}
