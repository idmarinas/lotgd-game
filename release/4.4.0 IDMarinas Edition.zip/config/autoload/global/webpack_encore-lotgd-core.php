<?php

return [
    'webpack_encore' => [
        'builds' => [
            //-- Need for each Encore Config build
            // 'example' => 'path/to/build/example',
        ]
    ],
];
