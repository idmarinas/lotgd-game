<?php
    //Expire Chars
    require_once 'lib/expire_chars.php';
