<?php

return [
    'service_manager' => [
        'delegators' => [],
    ],
];
