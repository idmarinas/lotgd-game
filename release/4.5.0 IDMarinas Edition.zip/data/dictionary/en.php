<?php

/**
 * Example of dictionary for censor words.
 *
 * @see http://banbuilder.com
 */
array_push($badwords,
    'ejaculate',
    'teets',
    'twaty'
);
