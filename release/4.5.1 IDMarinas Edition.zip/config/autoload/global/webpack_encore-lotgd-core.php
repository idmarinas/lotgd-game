<?php

return [
    'webpack_encore' => [
        'builds' => [
            'lotgd' => 'public/build/lotgd' //-- This is the LOTGD Core package
            //-- Need for each Encore Config build
            // 'example' => 'path/to/build/example',
        ]
    ],
];
