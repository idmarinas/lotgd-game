<?php

use Lotgd\Core\Component\Filesystem;
use Tracy\Debugger;

global $session, $fiveminuteload;

\define('ALLOW_ANONYMOUS', false);
\define('OVERRIDE_FORCED_NAV', true);

require_once 'common.php';

$op    = (string) \LotgdRequest::getQuery('op');
$class = (string) \LotgdRequest::getQuery('cache');

$textDomain = 'ajax-datacache';

if ('twigtemplates' == $class)
{
    $file = new Filesystem();

    try
    {
        $file->remove('storage/cache/template/');
        $file->dumpFile('storage/cache/template/.gitkeep', '');

        echo 'ok';
    }
    catch (\Throwable $th)
    {
        Debugger::log($th);

        echo 'fail';
    }
}
elseif (\LotgdLocator::has($class))
{
    $cache = \LotgdLocator::get($class);

    if ('optimize' == $op)
    {
        $cache->optimize();

        echo 'ok';
    }
    elseif ('clearexpire' == $op)
    {
        $cache->clearExpired();

        echo 'ok';
    }
    elseif ('clearall' == $op)
    {
        $result = 'ok';

        try
        {
            $cache->flush();
        }
        catch (\Exception $ex)
        {
            //-- With this avoid a 500 server error
            //-- In some cases it may not be possible to delete certain files and directories because it not have permissions.
            $result = \LotgdTranslator::t('clear.all', [], $textDomain);
        }

        echo $result;
    }
    elseif ('clearbyprefix' == $op)
    {
        $prefix = \LotgdRequest::getQuery('prefix');

        $cache->clearByPrefix($prefix);

        echo 'ok';
    }
    else
    {
        echo \LotgdTranslator::t('not.found', [], $textDomain);
    }
}
else
{
    echo \LotgdTranslator::t('factory', ['name' => $class], $textDomain);
}
