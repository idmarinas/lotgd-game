<?php

// translator ready
// addnews ready
// mail ready
require_once 'common.php';
require_once 'lib/systemmail.php';

check_su_access(SU_EDIT_COMMENTS);

$textDomain = 'page-bios';

//-- Init page
\LotgdResponse::pageStart('title', [], $textDomain);

$op = (string) \LotgdRequest::getQuery('op');
$userid = (int) \LotgdRequest::getQuery('charid');

$repository = \Doctrine::getRepository(\Lotgd\Core\Entity\Characters::class);

$params = [
    'textDomain' => $textDomain
];

if ('block' == $op || 'unblock' == $op)
{
    $message = "player.{$op}.fail";
    $flashMessage = 'addErrorMessage';

    if ($repository->blockCharacterBio($userid))
    {
        $message = "player.{$op}.success";
        $flashMessage = 'addSuccessMessage';

        $subj = ["mail.{$op}.subject", [], $textDomain];
        $msg = ["mail.{$op}.message", [], $textDomain];

        systemmail($userid, $subj, $msg);
    }

    \LotgdFlashMessages::{$flashMessage}(\LotgdTranslator::t($message, [], $textDomain));
}

$params['unblocked'] = $repository->getCharactersUnblockedBio();
$params['blocked'] = $repository->getCharactersBlockedBio();

\LotgdNavigation::superuserGrottoNav();

\LotgdNavigation::addNav('bios.category.moderation');

if ($session['user']['superuser'] & SU_EDIT_COMMENTS)
{
    \LotgdNavigation::addNav('bios.nav.moderation', 'moderate.php');
}

\LotgdNavigation::addNav('bios.nav.refresh', 'bios.php');

\LotgdResponse::pageAddContent(\LotgdTheme::render('@core/pages/bios.html.twig', $params));

//-- Finalize page
\LotgdResponse::pageEnd();

