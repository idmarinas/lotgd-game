<?php

// This file is obsolete and for get a Jaxon-PHP only need get it's factory, like this example
global $lotgdJaxon;

// This is only for compatibility is better use get factory
$lotgdJaxon = \LotgdLocator::get(Lotgd\Core\Jaxon::class);
