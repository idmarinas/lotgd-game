<?php

return [
    'input_filter_specs' => [
    ],
];
