<?php

/**
 * Create forms via Service Manager and Form Factory.
 */

return [
    'forms' => [
    ],
];
