<?php

define('ALLOW_ANONYMOUS', true);

require_once 'public/common.php';
require 'lib/newday/commentcleanup.php';
