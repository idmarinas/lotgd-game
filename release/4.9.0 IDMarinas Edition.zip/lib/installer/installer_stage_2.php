<?php

\LotgdResponse::pageAddContent(\LotgdTheme::render('@core/pages/installer/stage-2.html.twig', []));
