<?php

// translator ready
// addnews ready
// mail ready

$temp_user_stats = ['is_suspended' => false];

function apply_temp_stat($name, $value, $type = 'add')
{
    global $session, $temp_user_stats;

    if ('add' == $type)
    {
        if ( ! isset($temp_user_stats['add']))
        {
            $temp_user_stats['add'] = [];
        }
        $temp = &$temp_user_stats['add'];

        if ( ! isset($temp[$name]))
        {
            $temp[$name] = $value;
        }
        else
        {
            $temp[$name] += $value;
        }

        if ( ! $temp_user_stats['is_suspended'])
        {
            $session['user'][$name] += $value;
        }

        return true;
    }
    else
    {
        \LotgdResponse::pageDebug("Temp stat type {$type} is not supported.");

        return false;
    }
}

function check_temp_stat($name, $color = false)
{
    global $temp_user_stats, $session;

    if (isset($temp_user_stats['add'][$name]))
    {
        $v = $temp_user_stats['add'][$name];
    }
    else
    {
        $v = 0;
    }

    if (false === $color)
    {
        return 0 == $v ? '' : $v;
    }
    else
    {
        if ($v > 0)
        {
            return ' `&('.($session['user'][$name] - \round($v, 1)).'`@+'.\round($v, 1).'`&)';
        }
        else
        {
            return 0 == $v ? '' : ' `&('.($session['user'][$name] + \round($v, 1)).'`$-'.\round($v, 1).'`&)';
        }
    }
}

function suspend_temp_stats()
{
    global $session, $temp_user_stats;

    if ( ! $temp_user_stats['is_suspended'])
    {
        \reset($temp_user_stats);

        foreach ($temp_user_stats as $type => $collection)
        {
            if ('add' == $type)
            {
                \reset($collection);

                foreach ($collection as $attribute => $value)
                {
                    $session['user'][$attribute] -= $value;
                }
            }
        }
        $temp_user_stats['is_suspended'] = true;

        return true;
    }
    else
    {
        return false;
    }
}

function restore_temp_stats()
{
    global $session, $temp_user_stats;

    if ($temp_user_stats['is_suspended'])
    {
        \reset($temp_user_stats);

        foreach ($temp_user_stats as $type => $collection)
        {
            if ('add' == $type)
            {
                \reset($collection);

                foreach ($collection as $attribute => $value)
                {
                    $session['user'][$attribute] += $value;
                }
            }
        }
        $temp_user_stats['is_suspended'] = false;

        return true;
    }
    else
    {
        return false;
    }
}
